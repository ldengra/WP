<footer class="main-footer">
		<div class="container">
			<div class="f_left">
				<p>&copy; <?php the_date('Y'); ?> - <?php bloginfo('name'); ?></p>
				
			</div>


		</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>